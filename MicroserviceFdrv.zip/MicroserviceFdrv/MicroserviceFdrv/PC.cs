﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MicroserviceFdrv
{
    public class PC
    {
        public Int16 Model { get; set; }
        public Int16 Speed { get; set; }
        public Int16 Ram { get; set; }
        public Int16 Hd { get; set; }
        public string Rd { get; set; }
        public int Price { get; set; }
    }
}
